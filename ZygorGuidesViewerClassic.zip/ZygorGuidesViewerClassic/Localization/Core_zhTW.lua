if GetLocale()~="zhTW" then return end

ZygorGuidesViewer_L("Main", "zhTW", function() return {
	MainFont = [[Fonts\bLEI00D.ttf]],
	MainFontBold = [[Fonts\bLEI00D.ttf]],
} end)
