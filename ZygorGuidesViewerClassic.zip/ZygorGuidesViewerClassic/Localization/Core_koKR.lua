if GetLocale()~="koKR" then return end

ZygorGuidesViewer_L("Main", "koKR", function() return {
	MainFont = [[Fonts\2002.TTF]],
	MainFontBold = [[Fonts\2002.TTF]],
} end)
